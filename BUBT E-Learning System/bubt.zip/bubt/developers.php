<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3"> 
										<center>
										<img id="developers" src="admin/images/nihal.jpg" class="img-circle">
										<hr>
										<p>Name: Sajidul Qyum Nihal</p>
										<p>Address: Chittagong</p>
										<p>Email: sajidulqyum@gmail.com</p>
										<p>Position: Programmer</p>
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/nayem.jpg" class="img-circle">
								<hr>
																				<p>Name: Rakib Hassan Nayem</p>

										<p>Address: Tangail</p>
										<p>Email: rakibhassan@gmail.com</p>
										<p>Position: Programmer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/maharin.jpg" class="img-circle">
								<hr>
												<p>Name: Maharin Afroj</p>
										<p>Address: Savar</p>
										<p>Email: maharinafroj@gmail.com</p>
										<p>Position: Designer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/saim.jpg" class="img-circle">
								<hr>
												<p>Name: Saim Bhuiyan</p>
										<p>Address: Cumilla</p>
										<p>Email: saimbhuiyan@gmail.com</p>
										<p>Position: Data Analyst</p>
								</center>
								</div>
								<div class="span3">
															<center>
								<img id="developers" src="admin/images/tasnim.jpg" class="img-circle">
								<hr>
												<p>Name: Tasnim Islam</p>
										<p>Address: Cumilla</p>
										<p>Email: tasnimislam@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer1.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>