<center>
		<footer>
		
		<p style="color:white">β Version Developed By SB | SQ | MA | RHN | TI</p>
		
		</footer>
</center>

