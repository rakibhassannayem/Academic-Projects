				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/BUBTlogo.png">
						</div>	
						<div class="span8">
						
								<div class="title">
								<p class="chmsc"; style="font-size:medium; color:white">Bangladesh University of Business & Technology</p>
							<h3>
                            <br/>
							<b><p style="font-size:90px; color:cyan; font-family:Intro">OLMS</p></b>
						     </h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<b><p>BUBT EXCELS:</p></b></br>
												<p>Committed to Academic Excellence</p>
	
								</div>		
						</div>		
				</div>