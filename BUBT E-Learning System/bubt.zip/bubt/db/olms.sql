-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2023 at 07:40 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olms`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `activity_log_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`activity_log_id`, `username`, `date`, `action`) VALUES
(1, 'admin', '2023-06-26 22:41:29', 'Add School Year 2022-2023'),
(2, 'admin', '2023-06-26 22:41:41', 'Add School Year 2023-2024'),
(3, 'admin', '2023-07-03 20:18:30', 'Add Subject PHY 101'),
(4, 'admin', '2023-07-03 20:21:27', 'Add Subject CSE 111'),
(5, 'admin', '2023-07-03 20:24:47', 'Add Subject CSE 112'),
(6, 'admin', '2023-07-03 20:26:27', 'Add Subject CSE 121'),
(7, 'admin', '2023-07-03 20:29:06', 'Add Subject ENG 101'),
(8, 'admin', '2023-07-03 20:34:35', 'Add Subject ENG 111'),
(9, 'admin', '2023-07-03 20:35:39', 'Add Subject EEE 102'),
(10, 'admin', '2023-07-03 20:36:03', 'Add Subject EEE 101'),
(11, 'admin', '2023-07-03 20:36:51', 'Add Subject MAT 121'),
(12, 'admin', '2023-07-03 20:39:11', 'Add Subject CSE 100'),
(13, 'admin', '2023-07-03 20:43:34', 'Add Subject STA 231'),
(14, 'admin', '2023-07-03 20:47:08', 'Add Subject CSE 103'),
(15, 'admin', '2023-07-03 20:47:39', 'Add Subject CSE 213'),
(16, 'admin', '2023-07-03 20:48:23', 'Add Subject CSE 242'),
(17, 'admin', '2023-07-03 20:48:50', 'Add Subject CSE 241'),
(18, 'admin', '2023-07-03 20:49:41', 'Add Subject EEE 211'),
(19, 'admin', '2023-07-03 20:50:04', 'Add Subject EEE 212'),
(20, 'admin', '2023-07-06 20:39:33', 'Add Subject CSE 207');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `answer_id` int(11) NOT NULL,
  `quiz_question_id` int(11) NOT NULL,
  `answer_text` varchar(100) NOT NULL,
  `choices` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`answer_id`, `quiz_question_id`, `answer_text`, `choices`) VALUES
(1, 1, 'Messi', 'A'),
(2, 1, 'neymar', 'B'),
(3, 1, 'cr7', 'C'),
(4, 1, 'mbappe', 'D'),
(5, 3, 'www', 'A'),
(6, 3, 'fsrtgrt', 'B'),
(7, 3, 't6yerg', 'C'),
(8, 3, 'rdtye', 'D');

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `assignment_id` int(11) NOT NULL,
  `floc` varchar(300) NOT NULL,
  `fdatein` varchar(100) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`assignment_id`, `floc`, `fdatein`, `fdesc`, `teacher_id`, `class_id`, `fname`) VALUES
(3, 'admin/uploads/4583_File_java theory.pptx', '2023-07-23 22:17:59', 'sssss', 1, 1, 'nihal'),
(4, 'admin/uploads/1965_File_Tanny_CV.doc', '2023-07-23 22:23:45', 'sjijoifueyr98', 1, 0, 'Blockbuster'),
(5, 'admin/uploads/3998_File_19203103011.pdf', '2023-07-25 20:50:13', 'hi hello', 1, 1, 'ssddd'),
(6, 'admin/uploads/8317_File_Lecture 2.pptx', '2023-07-25 20:51:28', 'vbbbbb', 1, 1, 'xvvvvvvvvvvvb');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_name`) VALUES
(1, 'CSE-45/1'),
(2, 'CSE-45/2'),
(3, 'CSE-45/3'),
(4, 'CSE-46/1'),
(5, 'CSE-46/2'),
(6, 'CSE-46/3'),
(7, 'CSE-44/1'),
(8, 'CSE-44/2'),
(9, 'CSE-44/3'),
(10, 'EEE-42/1'),
(11, 'EEE-42/2'),
(12, 'EEE-42/3');

-- --------------------------------------------------------

--
-- Table structure for table `class_quiz`
--

CREATE TABLE `class_quiz` (
  `class_quiz_id` int(11) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `quiz_time` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_quiz`
--

INSERT INTO `class_quiz` (`class_quiz_id`, `teacher_class_id`, `quiz_time`, `quiz_id`) VALUES
(1, 1, 1800, 1);

-- --------------------------------------------------------

--
-- Table structure for table `class_subject_overview`
--

CREATE TABLE `class_subject_overview` (
  `class_subject_overview_id` int(11) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `content` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `content_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`content_id`, `title`, `content`) VALUES
(1, 'mission', '<pre>\r\n<span style=\"font-size:22px\"><strong>Mission</strong></span></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"font-size:20px\"><span style=\"font-family:lato,sans-serif\">To provide quality education to students through innovative teaching and learning process at an affordable cost for transforming the BUBT graduates into competent human resources.&nbsp;</span></span></p>\r\n'),
(2, 'vision', '<pre>\r\n<span style=\"font-size:22px\"><strong>Vision</strong></span></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"font-size:20px\"><span style=\"font-family:lato,sans-serif\">BUBT aims to be a leading educational institution for academic excellence, innovation and research.</span><span style=\"font-family:lato,sans-serif\">&nbsp;</span></span></p>\r\n'),
(3, 'Calendar', '<table align=\"center\" border=\"1\">\r\n	<caption><strong><span style=\"font-size:18px\">Calendar of Events</span></strong></caption>\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align:center\"><span style=\"font-size:18px\">Date</span></td>\r\n			<td style=\"text-align:center\"><span style=\"font-size:18px\">Day</span></td>\r\n			<td style=\"text-align:center\"><span style=\"font-size:18px\">Activities</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">Tuesday - Monday</span></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">Student advising and registration</span></p>\r\n\r\n			<p>&nbsp;</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">Tuesday - Monday</span></p>\r\n			</td>\r\n			<td><span style=\"font-size:18px\">Student advising and registration</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n			</td>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">Tuesday - Monday</span></p>\r\n			</td>\r\n			<td><span style=\"font-size:18px\">Student advising and registration</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n			</td>\r\n			<td><span style=\"font-size:18px\">Tuesday - Monday</span></td>\r\n			<td><span style=\"font-size:18px\">Student advising and registration</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n			</td>\r\n			<td><span style=\"font-size:18px\">Tuesday - Monday</span></td>\r\n			<td><span style=\"font-size:18px\">Student advising and registration</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n			</td>\r\n			<td><span style=\"font-size:18px\">Tuesday - Monday</span></td>\r\n			<td><span style=\"font-size:18px\">Student advising and registration</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n			</td>\r\n			<td><span style=\"font-size:18px\">Tuesday - Monday</span></td>\r\n			<td><span style=\"font-size:18px\">Student advising and registration</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><span style=\"font-size:18px\">21 Mar - 03 April 2023</span></p>\r\n			</td>\r\n			<td><span style=\"font-size:18px\">Tuesday - Monday</span></td>\r\n			<td><span style=\"font-size:18px\">Student advising and registration</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;\r\n<p>&nbsp;\r\n<p>&nbsp;\r\n<p>&nbsp;\r\n<p>&nbsp;\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n</p>\r\n</p>\r\n</p>\r\n</p>\r\n</p>\r\n'),
(4, 'Directories', '<pre>\r\n<strong><span style=\"font-size:20px\">Directories</span></strong></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"font-size:18px\"><strong>Admission Hotline Number</strong><br />\r\n<a href=\"tel:01810033733\">01810033733</a>,&nbsp;<a href=\"tel:01810033701\">01810033701</a>,&nbsp;<a href=\"tel:01810033702\">01810033702</a>,&nbsp;<a href=\"tel:01810033703\">01810033703</a>,&nbsp;<a href=\"tel:01810033704\">01810033704</a>,&nbsp;<a href=\"tel:01810033705\">01810033705</a></span></p>\r\n\r\n<p><span style=\"font-size:18px\"><strong>Phone No</strong><br />\r\n4803-6351, 4803-6352, 4803-6353</span></p>\r\n\r\n<p><span style=\"font-size:18px\"><strong>Mobile</strong><br />\r\n<a href=\"tel:01967169189\">01967169189</a>,&nbsp;<a href=\"tel:01845734337\">01845734337</a>,&nbsp;<a href=\"tel:01680050630\">01680050630</a>,&nbsp;<a href=\"tel:01741129235\">01741129235</a>,&nbsp;<a href=\"tel:01554882075\">01554882075</a></span></p>\r\n\r\n<p><span style=\"font-size:18px\"><strong>WhatsApp</strong><br />\r\n<a href=\"https://wa.me/%2B8801680050630\">01680050630</a></span></p>\r\n\r\n<p><span style=\"font-size:18px\"><strong>Viber</strong><br />\r\n<a href=\"viber://chat?number=%2B8801680050630\">01680050630</a></span></p>\r\n\r\n<p><span style=\"font-size:18px\"><strong>Email</strong><br />\r\ninfo@bubt.edu.bd</span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"font-size:18px\"><strong>Website</strong><br />\r\n<a href=\"http://bubt.edu.bd/\">http://bubt.edu.bd</a></span></p>\r\n\r\n<p>&nbsp;</p>\r\n'),
(5, 'Campuses', '<pre>\r\n<span style=\"font-size:20px\"><strong>Campuses</strong></span>\r\n\r\n</pre>\r\n\r\n<p><span style=\"font-size:18px\">The permanent campus of <strong>BUBT</strong> is located at Rupnagar, Mirpur-2, Dhaka-1216 with three spacious buildings and with all facilities for higher education. It is surrounded by a good number of educational institutions in an excellent academic atmosphere. The campus of <strong>BUBT</strong> has excellent communication links from all parts of the Dhaka City as well as from outside the City by cars, buses, taxies, rickshaws etc.</span></p>\r\n'),
(6, 'History', '<pre>\r\n<span style=\"font-size:20px\"><strong>History</strong></span></pre>\r\n\r\n<p><span style=\"font-size:18px\"><strong>Bangladesh University of Business and Technology (BUBT)</strong>&nbsp;was established under the Private University Act in the year 2003 modelled on North American Universities, with the approval of the University Grants Commission (UGC) and the Ministry of Education, Government of Bangladesh. It was founded by Dhaka Commerce College, Mirpur- 2, Dhaka, and is managed by a Board of Trustees and a Syndicate. BUBT is one of the leading universities in the private sector of Bangladesh. It has been providing quality education and training since its very inception. At present BUBT has established itself as a top ranking Private University in the country, not only by fulfilling all of the requirements of the Private University Act, 2010, but also by maintaining the standard of education, research facilities, transparent examination system, updated academic programs, necessary physical infrastructures, co-curricular and extra-curricular activities, modern facilities for the students and a disciplined environment.</span></p>\r\n\r\n<p>&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `dean` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`, `dean`) VALUES
(1, 'Computer Science and Engineering', 'Md. Saifur Rahman'),
(2, 'Electrical and Electronic Engineering', 'Prof. Dr. Md. Anwar Hossain'),
(3, 'Finance', 'Md. Sayeem Bin Hafiz'),
(4, 'Management', 'Dr. Sharmina Afrin'),
(5, 'Accounting', 'Prof. Dr. Syed Masud Husain'),
(6, 'Marketing', 'Mohammad Maniruzzaman'),
(7, 'Textile Engineering', 'Abdullah Bin Samad'),
(8, 'Civil Engineering', 'Prof. Dr. Ali Ahmed');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `event_title` varchar(100) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `date_start` varchar(100) NOT NULL,
  `date_end` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_title`, `teacher_class_id`, `date_start`, `date_end`) VALUES
(1, 'ICPC Asia Dhaka Regional Contest', 0, '01/01/2023', '01/20/2023'),
(2, 'BUBT Job Fair', 0, '03/10/2023', '03/15/2023'),
(3, 'CSE 207', 1, '07/21/2023', '11/20/2023');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL,
  `floc` varchar(500) NOT NULL,
  `fdatein` varchar(200) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `uploaded_by` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`file_id`, `floc`, `fdatein`, `fdesc`, `teacher_id`, `class_id`, `fname`, `uploaded_by`) VALUES
(1, 'admin/uploads/7086_File_Ethics.pptx', '2023-07-19 20:44:54', 'Lesson-1', 1, 1, 'Ethics', 'Ashiqur Rahman'),
(2, 'admin/uploads/1293_File_lecture 1.pptx', '2023-07-21 21:52:08', 'plzz download your file', 1, 1, 'lec1', 'Ashiqur Rahman');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `message_id` int(11) NOT NULL,
  `reciever_id` int(11) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` varchar(100) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `reciever_name` varchar(50) NOT NULL,
  `sender_name` varchar(200) NOT NULL,
  `message_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `reciever_id`, `content`, `date_sended`, `sender_id`, `reciever_name`, `sender_name`, `message_status`) VALUES
(4, 2, 'plzz submit your assignment', '2023-07-22 19:23:50', 4, 'Abdullah Tanim', 'Shamim  Ahmed', ''),
(6, 13, 'hi', '2023-07-22 19:29:56', 7, 'Maharin Afroj', 'Sajidul Qyum', ''),
(7, 10, 'Saree poiro kalke', '2023-07-22 22:09:29', 1, 'Farjana Akter', 'Saim Bhuiyan', ''),
(8, 7, 'HELLO VAI', '2023-07-22 22:12:16', 15, 'Sajidul Qyum', 'Rakib Hassan ', '');

-- --------------------------------------------------------

--
-- Table structure for table `message_sent`
--

CREATE TABLE `message_sent` (
  `message_sent_id` int(11) NOT NULL,
  `reciever_id` int(11) NOT NULL,
  `content` varchar(200) NOT NULL,
  `date_sended` varchar(100) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `reciever_name` varchar(100) NOT NULL,
  `sender_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `message_sent`
--

INSERT INTO `message_sent` (`message_sent_id`, `reciever_id`, `content`, `date_sended`, `sender_id`, `reciever_name`, `sender_name`) VALUES
(6, 0, 'hello sir', '2023-07-22 11:11:08', 7, ' ', ' '),
(7, 1, 'hi sir\r\n', '2023-07-22 11:17:07', 7, 'Ashiqur  Rahman', 'Sajidul Qyum'),
(16, 1, 'hello vai\r\n', '2023-07-22 19:03:12', 7, 'Saim Bhuiyan', 'Sajidul Qyum'),
(18, 1, 'hello sir', '2023-07-22 19:22:10', 4, 'Ashiqur  Rahman', 'Shamim  Ahmed'),
(19, 2, 'plzz submit your assignment', '2023-07-22 19:23:50', 4, 'Abdullah Tanim', 'Shamim  Ahmed'),
(20, 1, 'hi', '2023-07-22 19:27:59', 16, 'Saim Bhuiyan', 'Sudipa Saha'),
(21, 13, 'hi', '2023-07-22 19:29:56', 7, 'Maharin Afroj', 'Sajidul Qyum'),
(22, 10, 'Saree poiro kalke', '2023-07-22 22:09:29', 1, 'Farjana Akter', 'Saim Bhuiyan'),
(23, 7, 'HELLO VAI', '2023-07-22 22:12:16', 15, 'Sajidul Qyum', 'Rakib Hassan ');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `notification` varchar(100) NOT NULL,
  `date_of_notification` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notification_id`, `teacher_class_id`, `notification`, `date_of_notification`, `link`) VALUES
(1, 1, 'Add Practice Quiz file', '2023-08-07 23:03:22', 'student_quiz_list.php');

-- --------------------------------------------------------

--
-- Table structure for table `notification_read`
--

CREATE TABLE `notification_read` (
  `notification_read_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_read` varchar(50) NOT NULL,
  `notification_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_read_teacher`
--

CREATE TABLE `notification_read_teacher` (
  `notification_read_teacher_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `student_read` varchar(100) NOT NULL,
  `notification_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question_type`
--

CREATE TABLE `question_type` (
  `question_type_id` int(11) NOT NULL,
  `question_type` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_type`
--

INSERT INTO `question_type` (`question_type_id`, `question_type`) VALUES
(1, 'Multiple Choice'),
(2, 'True or False');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL,
  `quiz_title` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `quiz_description` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `date_added` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`quiz_id`, `quiz_title`, `quiz_description`, `date_added`, `teacher_id`) VALUES
(1, '1st quiz', 'CSE 207', '2023-08-07 23:00:34', 1);

-- --------------------------------------------------------

--
-- Table structure for table `quiz_question`
--

CREATE TABLE `quiz_question` (
  `quiz_question_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_text` varchar(100) NOT NULL,
  `question_type_id` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `date_added` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz_question`
--

INSERT INTO `quiz_question` (`quiz_question_id`, `quiz_id`, `question_text`, `question_type_id`, `points`, `date_added`, `answer`) VALUES
(1, 1, '<p>What is my name?</p>\r\n', 1, 0, '2023-08-07 23:01:53', 'A'),
(2, 1, '<p>qdjkfhufi</p>\r\n', 2, 0, '2023-08-07 23:02:18', 'False'),
(3, 1, '<p>ieto9jeri8tugierjh8f</p>\r\n', 1, 0, '2023-08-07 23:02:34', 'D'),
(4, 1, '<p>tyewrte5ywqetgwrgs</p>\r\n', 2, 0, '2023-08-07 23:02:47', 'True');

-- --------------------------------------------------------

--
-- Table structure for table `school_year`
--

CREATE TABLE `school_year` (
  `school_year_id` int(11) NOT NULL,
  `school_year` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `school_year`
--

INSERT INTO `school_year` (`school_year_id`, `school_year`) VALUES
(1, '2022-2023'),
(2, '2023-2024');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `class_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `firstname`, `lastname`, `class_id`, `username`, `password`, `location`, `status`) VALUES
(21, 'Nabi Ul', 'Waqar', 1, '19203103006', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(6, 'Anika', 'Tabassum', 1, '19203103010', 'pass10', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered'),
(7, 'Sajidul', 'Qyum', 1, '19203103011', 'pass11', 'uploads/361812603_1756186018132057_6862507444994531214_n.jpg', 'Registered'),
(8, 'Sohaima', 'Hossain', 1, '19203103012', 'pass12', 'uploads/361815483_1345502229377149_4667133981729858784_n.jpg', 'Registered'),
(9, 'Nishat', 'Ahmed', 1, '19203103013', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(10, 'Farjana', 'Akter', 1, '19203103018', 'pass18', 'uploads/361542281_2871050276365276_2438133941890078353_n.jpg', 'Registered'),
(11, 'Khan Md', 'Sadbin Rifat', 1, '19203103019', 'pass19', 'uploads/361057374_6634569339934494_8646430694366487326_n.jpg', 'Registered'),
(12, 'Talha', 'Masum', 1, '19203103020', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(13, 'Maharin', 'Afroj', 1, '19203103021', 'pass21', 'uploads/361696269_661885675828201_2525014821329778255_n.jpg', 'Registered'),
(14, 'SK Araf', 'Ahmed', 1, '19203103024', 'pass24', 'uploads/361400339_265603609514802_8953378540532598295_n.jpg', 'Registered'),
(15, 'Rakib', 'Hassan ', 1, '19203103026', 'pass26', 'uploads/361631486_2997138737083535_5785898803079312937_n.jpg', 'Registered'),
(20, 'Redita', 'Redi', 1, '19203103004', '', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Unregistered'),
(19, 'Abdullah', 'Tanim', 1, '19203103002', 'pass02', 'uploads/361877741_977273410189225_2655774767801504680_n.jpg', 'Registered'),
(18, 'Saim', 'Bhuiyan', 1, '19203103001', 'pass01', 'uploads/saim1.jpg', 'Registered'),
(16, 'Sudipa', 'Saha', 2, '19203103039', 'pass39', 'uploads/maharin.jpg', 'Registered'),
(17, 'Abu', 'Talha', 1, '19203103029', 'pass29', 'uploads/NO-IMAGE-AVAILABLE.jpg', 'Registered');

-- --------------------------------------------------------

--
-- Table structure for table `student_assignment`
--

CREATE TABLE `student_assignment` (
  `student_assignment_id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  `floc` varchar(100) NOT NULL,
  `assignment_fdatein` varchar(50) NOT NULL,
  `fdesc` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `student_id` int(11) NOT NULL,
  `grade` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `student_assignment`
--

INSERT INTO `student_assignment` (`student_assignment_id`, `assignment_id`, `floc`, `assignment_fdatein`, `fdesc`, `fname`, `student_id`, `grade`) VALUES
(1, 1, 'admin/uploads/7241_File_id11_assignment.docx', '2023-07-22 20:17:54', 'Name:Sajidul Qyum', 'mid assignment', 7, '15'),
(2, 1, 'admin/uploads/9864_File_case-study-solution.doc', '2023-07-22 22:22:27', 'nayem', 'id26', 15, '15'),
(3, 6, 'admin/uploads/3696_File_AIassignment.docx', '2023-07-25 20:57:47', 'ssss', 'zzzs', 7, ''),
(4, 5, 'admin/uploads/6764_File_ITR-Shorab.xlsx', '2023-07-26 15:20:40', 'DXWQD', 'QWEW', 7, '10');

-- --------------------------------------------------------

--
-- Table structure for table `student_class_quiz`
--

CREATE TABLE `student_class_quiz` (
  `student_class_quiz_id` int(11) NOT NULL,
  `class_quiz_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_quiz_time` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `grade` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_class_quiz`
--

INSERT INTO `student_class_quiz` (`student_class_quiz_id`, `class_quiz_id`, `student_id`, `student_quiz_time`, `grade`) VALUES
(1, 1, 15, '3600', '2 out of 4'),
(2, 1, 18, '3600', '1 out of 4'),
(3, 1, 7, '3600', '2 out of 4');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL,
  `subject_code` varchar(100) NOT NULL,
  `subject_title` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `credits` float NOT NULL,
  `Pre_req` varchar(100) NOT NULL,
  `semester` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_code`, `subject_title`, `category`, `description`, `credits`, `Pre_req`, `semester`) VALUES
(1, 'PHY 101', 'Physics', '', '', 3, '', '1st'),
(2, 'CSE 111', 'Structured Programming Language', '', '', 3, '', '1st'),
(3, 'CSE 112', 'Structured Programming Language Lab', '', '', 1.5, '', '1st'),
(4, 'CSE 121', 'Object Oriented Programming Language', '', '', 3, '', '2nd'),
(5, 'ENG 101', 'English Language-I', '', '', 3, '', '2nd'),
(6, 'ENG 111', 'English Language-II', '', '', 3, '', '3rd'),
(7, 'EEE 102', 'Electrical Technology Lab', '', '', 1.5, '', '2nd'),
(8, 'EEE 101', 'Electrical Technology', '', '', 3, '', '2nd'),
(9, 'MAT 121', 'Linear Algebras and Differential Equations', '', '', 3, '', '1st'),
(10, 'CSE 100', 'Software Development I', '', '', 1.5, '', '4th'),
(11, 'STA 231', 'Statistics', '', '', 3, '', '2nd'),
(12, 'CSE 103', 'Discrete Mathematics', '', '', 3, '', '5th'),
(13, 'CSE 213', 'Theory of Computing & Automata Theory', '', '', 3, '', '4th'),
(14, 'CSE 242', 'Algorithms Lab', '', '', 1.5, '', '3rd'),
(15, 'CSE 241', 'Algorithms', '', '', 3, '', '3rd'),
(16, 'EEE 211', 'Electronic Devices and Circuits', '', '', 3, '', '3rd'),
(17, 'EEE 212', 'Electronic Devices and Circuits Lab', '', '', 1.5, '', '3rd'),
(18, 'CSE 207', 'Database Systems', '', '', 3, '', '5th');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  `location` varchar(200) NOT NULL,
  `about` varchar(500) NOT NULL,
  `teacher_status` varchar(20) NOT NULL,
  `teacher_stat` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `username`, `password`, `firstname`, `lastname`, `department_id`, `location`, `about`, `teacher_status`, `teacher_stat`) VALUES
(1, 'ashiqur', 'teacher1', 'Ashiqur ', 'Rahman', 1, 'uploads/ashiq.jpg', '', 'Registered', ''),
(2, 'meher', 'teacher2', 'Meher', 'Afroj', 1, 'uploads/NO-IMAGE-AVAILABLE.jpg', '', 'Registered', ''),
(3, 'nihal', '123456789', 'Mr', 'nihal', 1, 'uploads/NO-IMAGE-AVAILABLE.jpg', '', 'Registered', ''),
(4, 'shamim', 'teacher4', 'Shamim ', 'Ahmed', 1, 'uploads/NO-IMAGE-AVAILABLE.jpg', '', 'Registered', '');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_class`
--

CREATE TABLE `teacher_class` (
  `teacher_class_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `thumbnails` varchar(100) NOT NULL,
  `school_year` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `teacher_class`
--

INSERT INTO `teacher_class` (`teacher_class_id`, `teacher_id`, `class_id`, `subject_id`, `thumbnails`, `school_year`) VALUES
(1, 1, 1, 18, 'admin/uploads/thumbnails.jpg', '2023-2024'),
(2, 4, 2, 11, 'admin/uploads/thumbnails.jpg', '2023-2024'),
(3, 2, 1, 9, 'admin/uploads/thumbnails.jpg', '2023-2024');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_class_announcements`
--

CREATE TABLE `teacher_class_announcements` (
  `teacher_class_announcements_id` int(11) NOT NULL,
  `content` varchar(500) NOT NULL,
  `teacher_id` varchar(100) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `teacher_class_announcements`
--

INSERT INTO `teacher_class_announcements` (`teacher_class_announcements_id`, `content`, `teacher_id`, `teacher_class_id`, `date`) VALUES
(1, '<p>Notice for Intake 45/1<br />\r\nRegular class from 02:00 PM<br />\r\nThursday (13/7/2023)<br />\r\nRoom will be announced later</p>\r\n', '1', 1, '2023-07-19 20:43:14');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_class_student`
--

CREATE TABLE `teacher_class_student` (
  `teacher_class_student_id` int(11) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `teacher_class_student`
--

INSERT INTO `teacher_class_student` (`teacher_class_student_id`, `teacher_class_id`, `student_id`, `teacher_id`) VALUES
(2, 1, 2, 1),
(3, 1, 3, 1),
(4, 1, 4, 1),
(5, 1, 5, 1),
(6, 1, 6, 1),
(7, 1, 7, 1),
(8, 1, 8, 1),
(9, 1, 9, 1),
(10, 1, 10, 1),
(11, 1, 11, 1),
(12, 1, 12, 1),
(13, 1, 13, 1),
(14, 1, 14, 1),
(15, 1, 15, 1),
(16, 1, 1, 1),
(17, 2, 16, 4),
(18, 1, 17, 1),
(19, 3, 1, 2),
(20, 3, 2, 2),
(21, 3, 3, 2),
(22, 3, 4, 2),
(23, 3, 5, 2),
(24, 3, 6, 2),
(25, 3, 7, 2),
(26, 3, 8, 2),
(27, 3, 9, 2),
(28, 3, 10, 2),
(29, 3, 11, 2),
(30, 3, 12, 2),
(31, 3, 13, 2),
(32, 3, 14, 2),
(33, 3, 15, 2),
(34, 3, 17, 2),
(35, 1, 18, 1),
(36, 1, 19, 1);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_notification`
--

CREATE TABLE `teacher_notification` (
  `teacher_notification_id` int(11) NOT NULL,
  `teacher_class_id` int(11) NOT NULL,
  `notification` varchar(100) NOT NULL,
  `date_of_notification` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `student_id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `lastname`) VALUES
(1, 'admin', 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE `user_log` (
  `user_log_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `login_date` varchar(30) NOT NULL,
  `logout_date` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_log`
--

INSERT INTO `user_log` (`user_log_id`, `username`, `login_date`, `logout_date`, `user_id`) VALUES
(1, 'admin', '2023-06-26 15:20:56', '2023-08-06 22:50:25', 1),
(2, 'admin', '2023-06-26 15:26:27', '2023-08-06 22:50:25', 1),
(3, 'admin', '2023-06-26 22:41:03', '2023-08-06 22:50:25', 1),
(4, 'admin', '2023-06-28 11:57:17', '2023-08-06 22:50:25', 1),
(5, 'admin', '2023-07-03 19:55:34', '2023-08-06 22:50:25', 1),
(6, 'admin', '2023-07-05 11:10:37', '2023-08-06 22:50:25', 1),
(7, 'admin', '2023-07-06 20:17:25', '2023-08-06 22:50:25', 1),
(8, 'admin', '2023-07-07 19:45:23', '2023-08-06 22:50:25', 1),
(9, 'admin', '2023-07-12 21:52:26', '2023-08-06 22:50:25', 1),
(10, 'admin', '2023-07-12 21:52:31', '2023-08-06 22:50:25', 1),
(11, 'admin', '2023-07-12 21:52:40', '2023-08-06 22:50:25', 1),
(12, 'admin', '2023-07-12 21:53:10', '2023-08-06 22:50:25', 1),
(13, 'admin', '2023-07-12 21:53:21', '2023-08-06 22:50:25', 1),
(14, 'admin', '2023-07-12 21:59:51', '2023-08-06 22:50:25', 1),
(15, 'admin', '2023-07-13 09:11:07', '2023-08-06 22:50:25', 1),
(16, 'admin', '2023-07-13 10:39:14', '2023-08-06 22:50:25', 1),
(17, 'admin', '2023-07-13 12:15:25', '2023-08-06 22:50:25', 1),
(18, 'admin', '2023-07-13 12:21:30', '2023-08-06 22:50:25', 1),
(19, 'admin', '2023-07-13 12:21:36', '2023-08-06 22:50:25', 1),
(20, 'admin', '2023-07-13 19:55:15', '2023-08-06 22:50:25', 1),
(21, 'admin', '2023-07-15 11:32:18', '2023-08-06 22:50:25', 1),
(22, 'admin', '2023-07-17 21:52:47', '2023-08-06 22:50:25', 1),
(23, 'admin', '2023-07-17 22:02:30', '2023-08-06 22:50:25', 1),
(24, 'admin', '2023-07-18 20:49:46', '2023-08-06 22:50:25', 1),
(25, 'admin', '2023-07-19 20:40:52', '2023-08-06 22:50:25', 1),
(26, 'admin', '2023-07-19 21:35:50', '2023-08-06 22:50:25', 1),
(27, 'admin', '2023-07-21 20:42:08', '2023-08-06 22:50:25', 1),
(28, 'admin', '2023-07-21 21:47:09', '2023-08-06 22:50:25', 1),
(29, 'admin', '2023-07-22 12:28:00', '2023-08-06 22:50:25', 1),
(30, 'admin', '2023-07-22 12:37:59', '2023-08-06 22:50:25', 1),
(31, 'admin', '2023-07-22 19:20:14', '2023-08-06 22:50:25', 1),
(32, 'admin', '2023-07-22 19:25:21', '2023-08-06 22:50:25', 1),
(33, 'admin', '2023-07-22 19:58:22', '2023-08-06 22:50:25', 1),
(34, 'admin', '2023-07-22 19:59:59', '2023-08-06 22:50:25', 1),
(35, 'admin', '2023-07-22 22:33:25', '2023-08-06 22:50:25', 1),
(36, 'admin', '2023-07-22 22:48:11', '2023-08-06 22:50:25', 1),
(37, 'admin', '2023-07-22 22:59:56', '2023-08-06 22:50:25', 1),
(38, 'admin', '2023-07-26 19:23:16', '2023-08-06 22:50:25', 1),
(39, 'admin', '2023-07-28 16:02:19', '2023-08-06 22:50:25', 1),
(40, 'admin', '2023-07-28 16:18:39', '2023-08-06 22:50:25', 1),
(41, 'admin', '2023-08-06 22:43:24', '2023-08-06 22:50:25', 1),
(42, 'admin', '2023-08-06 22:44:01', '2023-08-06 22:50:25', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`activity_log_id`);

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `class_quiz`
--
ALTER TABLE `class_quiz`
  ADD PRIMARY KEY (`class_quiz_id`);

--
-- Indexes for table `class_subject_overview`
--
ALTER TABLE `class_subject_overview`
  ADD PRIMARY KEY (`class_subject_overview_id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`content_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `message_sent`
--
ALTER TABLE `message_sent`
  ADD PRIMARY KEY (`message_sent_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `notification_read`
--
ALTER TABLE `notification_read`
  ADD PRIMARY KEY (`notification_read_id`);

--
-- Indexes for table `notification_read_teacher`
--
ALTER TABLE `notification_read_teacher`
  ADD PRIMARY KEY (`notification_read_teacher_id`);

--
-- Indexes for table `question_type`
--
ALTER TABLE `question_type`
  ADD PRIMARY KEY (`question_type_id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`quiz_id`);

--
-- Indexes for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD PRIMARY KEY (`quiz_question_id`);

--
-- Indexes for table `school_year`
--
ALTER TABLE `school_year`
  ADD PRIMARY KEY (`school_year_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_assignment`
--
ALTER TABLE `student_assignment`
  ADD PRIMARY KEY (`student_assignment_id`);

--
-- Indexes for table `student_class_quiz`
--
ALTER TABLE `student_class_quiz`
  ADD PRIMARY KEY (`student_class_quiz_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `teacher_class`
--
ALTER TABLE `teacher_class`
  ADD PRIMARY KEY (`teacher_class_id`);

--
-- Indexes for table `teacher_class_announcements`
--
ALTER TABLE `teacher_class_announcements`
  ADD PRIMARY KEY (`teacher_class_announcements_id`);

--
-- Indexes for table `teacher_class_student`
--
ALTER TABLE `teacher_class_student`
  ADD PRIMARY KEY (`teacher_class_student_id`);

--
-- Indexes for table `teacher_notification`
--
ALTER TABLE `teacher_notification`
  ADD PRIMARY KEY (`teacher_notification_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_log`
--
ALTER TABLE `user_log`
  ADD PRIMARY KEY (`user_log_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `activity_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `class_quiz`
--
ALTER TABLE `class_quiz`
  MODIFY `class_quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `class_subject_overview`
--
ALTER TABLE `class_subject_overview`
  MODIFY `class_subject_overview_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `content_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `message_sent`
--
ALTER TABLE `message_sent`
  MODIFY `message_sent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notification_read`
--
ALTER TABLE `notification_read`
  MODIFY `notification_read_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_read_teacher`
--
ALTER TABLE `notification_read_teacher`
  MODIFY `notification_read_teacher_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quiz_question`
--
ALTER TABLE `quiz_question`
  MODIFY `quiz_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `school_year`
--
ALTER TABLE `school_year`
  MODIFY `school_year_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `student_assignment`
--
ALTER TABLE `student_assignment`
  MODIFY `student_assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student_class_quiz`
--
ALTER TABLE `student_class_quiz`
  MODIFY `student_class_quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teacher_class`
--
ALTER TABLE `teacher_class`
  MODIFY `teacher_class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teacher_class_announcements`
--
ALTER TABLE `teacher_class_announcements`
  MODIFY `teacher_class_announcements_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teacher_class_student`
--
ALTER TABLE `teacher_class_student`
  MODIFY `teacher_class_student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `teacher_notification`
--
ALTER TABLE `teacher_notification`
  MODIFY `teacher_notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_log`
--
ALTER TABLE `user_log`
  MODIFY `user_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
