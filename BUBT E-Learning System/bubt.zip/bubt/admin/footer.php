<center>
		<footer>
		
		<p style="color: black">β Version Developed By SB | SQ | MA | RHN | TI</p>
		
		</footer>
</center>

