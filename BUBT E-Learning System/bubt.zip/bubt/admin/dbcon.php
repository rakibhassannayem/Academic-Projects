<?php
$conn = mysqli_connect('localhost','root','','olms') or die(mysqli_error());
?>